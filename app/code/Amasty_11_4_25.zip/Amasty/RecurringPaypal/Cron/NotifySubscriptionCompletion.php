<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Cron;

use Amasty\RecurringPaypal\Api\NewSubscriptionServiceInterface;
use Amasty\RecurringPaypal\Model\ConfigProvider;
use Amasty\RecurringPaypal\Model\SendCompletionEmail;

class NotifySubscriptionCompletion
{
    /**
     * @var ConfigProvider
     */
    private $configProvider;

    /**
     * @var NewSubscriptionServiceInterface
     */
    private $newSubscriptionService;

    /**
     * @var SendCompletionEmail
     */
    private $sendCompletionEmail;

    public function __construct(
        ConfigProvider $configProvider,
        NewSubscriptionServiceInterface $newSubscriptionService,
        SendCompletionEmail $sendCompletionEmail
    ) {
        $this->configProvider = $configProvider;
        $this->newSubscriptionService = $newSubscriptionService;
        $this->sendCompletionEmail = $sendCompletionEmail;
    }

    public function execute(): void
    {
        if (!$this->configProvider->isNotifySubscriptionCompletion()) {
            return;
        }

        $newSubscriptions = $this->newSubscriptionService->shuffleNewSubscriptions(SendCompletionEmail::MINUTES);
        foreach ($newSubscriptions as $newSubscription) {
            $this->sendCompletionEmail->send($newSubscription->getSubscriptionId());
        }
    }
}
