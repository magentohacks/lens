<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class UpdateTemplateIds implements DataPatchInterface
{
    private const SETTINGS_TO_UPDATE = [
        'amasty_recurring_payments_email_notification_email_template_subscription_purchased'
        => 'amasty_recurring_payments_email_notification_customer_notification_email_template_subscription_purchased',
        'amasty_recurring_payments_email_notification_email_template_trial_end'
        => 'amasty_recurring_payments_email_notification_customer_notification_email_template_trial_end',
        'amasty_recurring_payments_email_notification_email_template_subscription_paused'
        => 'amasty_recurring_payments_email_notification_customer_notification_email_template_subscription_paused',
        'amasty_recurring_payments_email_notification_email_template_subscription_canceled'
        => 'amasty_recurring_payments_email_notification_customer_notification_email_template_subscription_canceled',
        'amasty_recurring_payments_email_notification_email_template_authenticate'
        => 'amasty_recurring_payments_email_notification_customer_notification_email_template_authenticate'
    ];

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    public function __construct(ModuleDataSetupInterface $moduleDataSetup)
    {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    public static function getDependencies(): array
    {
        return [];
    }

    public function getAliases(): array
    {
        return [];
    }

    public function apply(): self
    {
        $connection = $this->moduleDataSetup->getConnection();
        $configTableName = $this->moduleDataSetup->getTable('core_config_data');

        foreach (self::SETTINGS_TO_UPDATE as $oldValue => $newValue) {
            $connection->update($configTableName, ['value' => $newValue], ['value = ?' => $oldValue]);
        }

        return $this;
    }
}
