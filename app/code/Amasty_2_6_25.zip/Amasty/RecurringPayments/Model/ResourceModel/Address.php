<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel;

use Amasty\RecurringPayments\Api\Subscription\AddressInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Address extends AbstractDb
{
    public const TABLE_NAME = 'amasty_recurring_payments_address';

    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, AddressInterface::KEY_ID);
    }
}
