<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Api\Data;

interface NewSubscriptionInterface
{
    public const ID = 'id';
    public const SUBSCRIPTION_ID = 'subscription_id';
    public const CREATED_AT = 'created_at';

    /**
     * @return int|null
     */
    public function getId(): ?int;

    /**
     * @return string
     */
    public function getSubscriptionId(): string;

    /**
     * @param string $subscriptionId
     * @return void
     */
    public function setSubscriptionId(string $subscriptionId): void;

    /**
     * @return string
     */
    public function getCreatedAt(): string;

    /**
     * @param string $createdAt
     * @return void
     */
    public function setCreatedAt(string $createdAt): void;
}
