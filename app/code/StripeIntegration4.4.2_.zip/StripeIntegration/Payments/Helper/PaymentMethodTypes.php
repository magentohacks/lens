<?php

namespace StripeIntegration\Payments\Helper;

class PaymentMethodTypes
{
    // Kept in case an override is needed
    public function getPaymentMethodTypes()
    {
        return null;
    }
}