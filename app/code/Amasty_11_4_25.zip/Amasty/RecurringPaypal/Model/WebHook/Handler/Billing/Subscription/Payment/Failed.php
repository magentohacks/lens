<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model\WebHook\Handler\Billing\Subscription\Payment;

use Amasty\RecurringPayments\Api\Generators\RecurringTransactionGeneratorInterface;
use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Model\Config;
use Amasty\RecurringPayments\Model\Config\Source\Status;
use Amasty\RecurringPayments\Model\Date;
use Amasty\RecurringPayments\Model\Email\AdminNotification;
use Amasty\RecurringPayments\Model\Subscription\Email\EmailNotifier;
use Amasty\RecurringPaypal\Api\WebHook\HandlerInterface;
use Amasty\RecurringPaypal\Model\Subscription\Cache as SubscriptionCache;
use Amasty\RecurringPaypal\Model\WebHook\Handler\Billing\Subscription;
use Magento\Sales\Api\OrderRepositoryInterface;

class Failed extends Subscription implements HandlerInterface
{
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var Date
     */
    private $date;

    /**
     * @var RecurringTransactionGeneratorInterface
     */
    private $recurringTransactionGenerator;

    public function __construct(
        Config $config,
        RepositoryInterface $subscriptionRepository,
        EmailNotifier $emailNotifier,
        SubscriptionCache $subscriptionCache,
        OrderRepositoryInterface $orderRepository,
        Date $date,
        RecurringTransactionGeneratorInterface $recurringTransactionGenerator,
        AdminNotification $adminNotification
    ) {
        parent::__construct($config, $subscriptionRepository, $emailNotifier, $subscriptionCache);

        $this->orderRepository = $orderRepository;
        $this->date = $date;
        $this->recurringTransactionGenerator = $recurringTransactionGenerator;
    }

    public function process(array $payload)
    {
        if (!($subscription = $this->getSubscription($payload))) {
            return;
        }

        $order = $this->orderRepository->get($subscription->getOrderId());

        $amount = $this->getAmount($payload);
        $currencyCode = $this->getCurrencyCode($payload);
        if (!$amount || !$currencyCode) {
            return;
        }

        $subscriptionId = $subscription->getSubscriptionId();

        $this->recurringTransactionGenerator->generate(
            $amount,
            (string)$order->getIncrementId(),
            $currencyCode,
            $payload['id'],
            Status::FAILURE,
            $subscriptionId,
            $this->date->convertFromUnix($payload['create_time'])
        );
    }

    private function getAmount(array $payload): ?float
    {
        if (isset($payload['resource']['billing_info']['last_failed_payment']['amount']['value'])) {
            return (float)$payload['resource']['billing_info']['last_failed_payment']['amount']['value'];
        }

        if (isset($payload['resource']['billing_info']['last_payment']['amount']['value'])) {
            return (float)$payload['resource']['billing_info']['last_payment']['amount']['value'];
        }

        return null;
    }

    private function getCurrencyCode(array $payload): ?string
    {
        if (isset($payload['resource']['billing_info']['last_failed_payment']['amount']['currency_code'])) {
            return $payload['resource']['billing_info']['last_failed_payment']['amount']['currency_code'];
        }

        if (isset($payload['resource']['billing_info']['last_payment']['amount']['currency_code'])) {
            return $payload['resource']['billing_info']['last_payment']['amount']['currency_code'];
        }

        return null;
    }
}
