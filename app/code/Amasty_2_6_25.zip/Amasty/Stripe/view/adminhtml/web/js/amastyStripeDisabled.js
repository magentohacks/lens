//disable mixins
window.amasty_stripe_disabled = true;
