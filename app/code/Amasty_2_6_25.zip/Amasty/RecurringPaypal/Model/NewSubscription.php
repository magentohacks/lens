<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model;

use Amasty\RecurringPaypal\Api\Data\NewSubscriptionInterface;
use Amasty\RecurringPaypal\Model\ResourceModel\NewSubscription as NewSubscriptionResource;
use Magento\Framework\Model\AbstractModel;

class NewSubscription extends AbstractModel implements NewSubscriptionInterface
{
    protected function _construct()
    {
        $this->_init(NewSubscriptionResource::class);
    }

    public function getId(): ?int
    {
        return ($this->_getData(self::ID) === null) ? null
            : (int)$this->_getData(self::ID);
    }

    public function getSubscriptionId(): string
    {
        return (string)$this->getData(self::SUBSCRIPTION_ID);
    }

    public function setSubscriptionId(string $subscriptionId): void
    {
        $this->setData(self::SUBSCRIPTION_ID, $subscriptionId);
    }

    public function getCreatedAt(): string
    {
        return (string)$this->getData(self::CREATED_AT);
    }

    public function setCreatedAt(string $createdAt): void
    {
        $this->setData(self::CREATED_AT, $createdAt);
    }
}
