<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel;

use Amasty\RecurringPayments\Api\Data\SubscriptionPlanInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class SubscriptionPlan extends AbstractDb
{
    public const TABLE_NAME = 'amasty_recurring_payments_subscription_plan';

    /**
     * init table name and id field
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(static::TABLE_NAME, SubscriptionPlanInterface::PLAN_ID);
    }
}
