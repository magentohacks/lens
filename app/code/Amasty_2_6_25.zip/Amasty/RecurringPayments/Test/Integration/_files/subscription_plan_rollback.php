<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

use Amasty\RecurringPayments\Api\Data\SubscriptionPlanInterface;
use Amasty\RecurringPayments\Api\SubscriptionPlanRepositoryInterface;
use Amasty\RecurringPayments\Model\Config\Source\BillingFrequencyUnit;
use Amasty\RecurringPayments\Model\Config\Source\PlanStatus;
use Magento\TestFramework\Helper\Bootstrap;

/** @var SubscriptionPlanRepositoryInterface $subscriptionPlanRepository */
$subscriptionPlanRepository = Bootstrap::getObjectManager()->get(SubscriptionPlanRepositoryInterface::class);
try {
    $subscriptionPlanRepository->deleteById(77);
} catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
}

try {
    $subscriptionPlanRepository->deleteById(88);
} catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
}
