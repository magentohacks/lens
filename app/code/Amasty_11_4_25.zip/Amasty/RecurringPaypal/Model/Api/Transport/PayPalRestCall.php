<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model\Api\Transport;

use Amasty\RecurringPaypal\Model\ConfigProvider;
use Amasty\RecurringPaypal\Exceptions\PayPalAuthorizationException;
use Amasty\RecurringPaypal\Exceptions\PayPalApiException;
use Magento\Framework\HTTP\Client\CurlFactory;
use Magento\Framework\HTTP\Client\Curl;
use Laminas\Http\Response;

class PayPalRestCall
{
    public const POST_AUTHORIZED_CODES = [
        Response::STATUS_CODE_200, Response::STATUS_CODE_201, Response::STATUS_CODE_204, Response::STATUS_CODE_100
    ];
    public const GET_AUTHORIZED_CODES = [Response::STATUS_CODE_200, Response::STATUS_CODE_201];

    /**
     * @var OAuthTokenCredential
     */
    private $credential;

    /**
     * @var ConfigProvider
     */
    private $config;

    /**
     * @var CurlFactory
     */
    private $curlFactory;

    /**
     * @var bool
     */
    private $isTokenRefresh = false;

    public function __construct(
        OAuthTokenCredential $credential,
        ConfigProvider $config,
        CurlFactory $curlFactory
    ) {
        $this->credential = $credential;
        $this->config = $config;
        $this->curlFactory = $curlFactory;
    }

    public function execute(string $path, string $method, array $payLoad = []): array
    {
        $uri = $this->config->getFullApiUrl($path);
        $response = [];

        try {
            switch ($method) {
                case 'POST':
                    $response = $this->post($uri, $payLoad);
                    break;
                case 'GET':
                    $response = $this->get($uri);
                    break;
                default:
                    throw new \RuntimeException('Undefined method in paypal api provider.');
            }
        } catch (PayPalAuthorizationException $e) {
            if ($this->isTokenRefresh) {
                throw new \RuntimeException($e->getMessage());
            }
            $this->credential->refreshTokenData();
            $this->isTokenRefresh = true;
            $response = $this->execute($path, $method, $payLoad);
        }

        return $response;
    }

    public function post(string $uri, array $body): array
    {
        $curl = $this->getApiContextCurl();
        $curl->post($uri, json_encode($body));

        //Cancel subscription api return 204 status code without data
        if ($curl->getStatus() === Response::STATUS_CODE_204) {
            return [];
        }

        $this->checkError($curl, 'POST');

        return json_decode($curl->getBody(), true);
    }

    public function get(string $uri): array
    {
        $curl = $this->getApiContextCurl();
        $curl->get($uri);
        $this->checkError($curl, 'GET');

        return json_decode($curl->getBody(), true);
    }

    public function getApiContextCurl(): Curl
    {
        $accessToken = $this->credential->getAccessToken();

        $curl = $this->curlFactory->create();
        $curl->addHeader('Authorization', 'Bearer ' . $accessToken);
        $curl->addHeader('Content-Type', 'application/json');

        return $curl;
    }

    public function checkError(Curl $curl, string $method): void
    {
        $curlStatus = $curl->getStatus();

        if ($curlStatus === Response::STATUS_CODE_401) {
            throw new PayPalAuthorizationException(__('Unauthorized: Access is denied due to invalid credentials.'));
        }

        if ($method === 'POST' && !in_array($curlStatus, self::POST_AUTHORIZED_CODES)) {
            $ex = new PayPalApiException(__('%1 POST request paypal api error.', $curlStatus));
            $ex->setData($curl->getBody());
            throw $ex;
        }

        if ($curlStatus === Response::STATUS_CODE_100) {
            $body = json_decode($curl->getBody(), true);

            if ((isset($body['name']) && $body['name'] === 'AUTHENTICATION_FAILURE')
                    || (isset($body['error']) && $body['error'] === 'invalid_token')) {
                throw new PayPalAuthorizationException(
                    __('Unauthorized: Access is denied due to invalid credentials.')
                );
            }
        }

        if ($method === 'GET' && !in_array($curlStatus, self::GET_AUTHORIZED_CODES)) {
            $ex = new PayPalApiException(__('%1 GET request paypal api error.', $curlStatus));
            $ex->setData($curl->getBody());
            throw $ex;
        }
    }
}
