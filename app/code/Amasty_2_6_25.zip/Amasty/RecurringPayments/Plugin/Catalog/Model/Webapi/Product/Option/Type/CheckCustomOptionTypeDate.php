<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Plugin\Catalog\Model\Webapi\Product\Option\Type;

use Magento\Catalog\Model\Webapi\Product\Option\Type\Date;

class CheckCustomOptionTypeDate
{
    public function beforeValidateUserValue(Date $subject, array $values): array
    {
        if (isset($values[$subject->getOption()->getId()]) && is_array($values[$subject->getOption()->getId()])) {
            if (isset($values[$subject->getOption()->getId()]['date_internal'])) {
                $values[$subject->getOption()->getId()] = $values[$subject->getOption()->getId()]['date_internal'];
            } else {
                unset($values[$subject->getOption()->getId()]);
            }
        }

        return [$values];
    }
}
