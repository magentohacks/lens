<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Api\WebHook;

use Magento\Framework\App\RequestInterface;

interface ProcessorInterface
{
    /**
     * @param RequestInterface $request
     * @return void
     */
    public function processRequest(RequestInterface $request);
}
