<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Api;

use Amasty\RecurringPaypal\Api\Data\NewSubscriptionInterface;

interface NewSubscriptionServiceInterface
{
    /**
     * @param NewSubscriptionInterface $newSubscription
     * @return void
     */
    public function add(NewSubscriptionInterface $newSubscription): void;

    /**
     * @return NewSubscriptionInterface[]
     */
    public function shuffleNewSubscriptions(?int $minutes): array;
}
