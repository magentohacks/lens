<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Api\Data;

/**
 * Interface ProductRecurringAttributesInterface

 */
interface ProductRecurringGroupInterface
{
    /**#@+
     * group of product attributes
     */
    public const SUBSCRIPTION_SETTINGS_GROUP = 'Subscription Settings';
    /**#@-*/
}
