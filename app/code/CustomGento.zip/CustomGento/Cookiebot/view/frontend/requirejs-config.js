var config = {
    config: {
        mixins: {
            'Magento_GoogleAnalytics/js/google-analytics': {
                'CustomGento_Cookiebot/js/google-analytics-mixin': true
            }
        }
    }
};
