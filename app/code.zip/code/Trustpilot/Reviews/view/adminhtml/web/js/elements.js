const TrustpilotElements = {
    IFRAME_ID                                   : 'trustbox_preview_frame',
    XPATH_FIELD_ID                              : 'trustpilotTrustbox_trustbox_trustbox_xpath',
    XPATH_FIELD_ID_INHERIT                      : 'trustpilotTrustbox_trustbox_trustbox_xpath_inherit',
    TRUSTBOX_CODE_SNIPPET_FIELD_ID              : 'trustpilotTrustbox_trustbox_trustbox_code_snippet',
    TRUSTBOX_CODE_SNIPPET_FIELD_ID_INHERIT      : 'trustpilotTrustbox_trustbox_trustbox_code_snippet_inherit',
    POSITION_FIELD_ID                           : 'trustpilotTrustbox_trustbox_trustbox_position',
    POSITION_FIELD_ID_INHERIT                   : 'trustpilotTrustbox_trustbox_trustbox_position_inherit',
    PAGE_FIELD_ID                               : 'trustpilotTrustbox_trustbox_trustbox_page',
    PAGE_FIELD_ID_INHERIT                       : 'trustpilotTrustbox_trustbox_trustbox_page_inherit',
    TRUSTBOX_FIELD_ID                           : 'trustpilotTrustbox_trustbox_trustbox_enable'
}
