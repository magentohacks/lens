---
name: Bug report 🐛
about: The library does not work as expected (please use not for troubleshooting)
---

<!--
Fill in provided template with information about the bug
Provide a short and reproducible code example
⚠ Failing to provide necessary information will cause the issue to be closed until appropriately updated.
See Contributing guidelines for further information
-->

### I found this bug

### This is mPDF and PHP version and environment (server/fpm/cli etc) I am using

### This is the PHP code snippet I use

```
<?php


```

### This is the HTML/CSS code snippet I use

```

```
