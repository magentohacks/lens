<?php

namespace StripeIntegration\Payments\Exception;

class SilentException extends LocalizedException
{

}
