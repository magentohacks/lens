**CRITICAL Magento (Adobe Commerce) Patch For APSB23-50**

APSB23-50 Patch for magento versions from 2.3.0 to 2.4.3

More info is here
https://helpx.adobe.com/security/products/magento/apsb23-50.html

Install via composer

```
composer install srinivas/module-apsb23-50-patch
```

Compatible for Version between : 2.3.0 - 2.4.3

