<?php

namespace StripeIntegration\Payments\Exception;

class AmountMismatchException extends GenericException
{

}
