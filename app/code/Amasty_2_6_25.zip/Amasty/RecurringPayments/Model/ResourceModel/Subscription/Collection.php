<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel\Subscription;

use Amasty\RecurringPayments\Model\ResourceModel\Subscription as SubscriptionResource;
use Amasty\RecurringPayments\Model\Subscription;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    public function _construct()
    {
        $this->_init(Subscription::class, SubscriptionResource::class);
    }
}
