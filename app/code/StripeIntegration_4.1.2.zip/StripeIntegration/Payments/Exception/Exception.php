<?php

namespace StripeIntegration\Payments\Exception;

class Exception extends GenericException
{

}
