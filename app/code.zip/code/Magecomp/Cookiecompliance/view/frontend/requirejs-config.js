var config = {
    paths: {
        "jquery.cookie": "Magecomp_Cookiecompliance/js/jquery.cookie"
    }
};
