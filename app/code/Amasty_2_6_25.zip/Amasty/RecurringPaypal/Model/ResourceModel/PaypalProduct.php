<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model\ResourceModel;

use Amasty\RecurringPaypal\Api\Data\ProductInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class PaypalProduct extends AbstractDb
{
    public const TABLE_NAME = 'amasty_recurring_payments_paypal_product';

    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, ProductInterface::ID);
    }
}
