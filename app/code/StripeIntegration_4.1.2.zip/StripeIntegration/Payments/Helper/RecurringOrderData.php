<?php

namespace StripeIntegration\Payments\Helper;

class RecurringOrderData
{
    public $discountObject = null;
}