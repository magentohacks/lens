<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model\Subscription\Create;

use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPayments\Model\Subscription\Create\CreateSubscriptionHandlerInterface;
use Amasty\RecurringPaypal\Api\NewSubscriptionServiceInterface;
use Amasty\RecurringPaypal\Api\ProductRepositoryInterface;
use Amasty\RecurringPaypal\Exceptions\PayPalApiException;
use Amasty\RecurringPaypal\Model\Api\Adapter;
use Amasty\RecurringPaypal\Model\ConfigProvider;
use Amasty\RecurringPaypal\Model\NewSubscription;
use Amasty\RecurringPaypal\Model\NewSubscriptionFactory;
use Amasty\RecurringPaypal\Model\PaypalProduct;
use Amasty\RecurringPaypal\Model\Processor\CreatePlan;
use Amasty\RecurringPaypal\Model\Processor\CreateProduct;
use Amasty\RecurringPaypal\Model\Processor\CreateSubscription;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Sales\Api\Data\OrderInterface;

class CreateSubscriptionHandler implements CreateSubscriptionHandlerInterface
{
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var CreateProduct
     */
    private $createProduct;

    /**
     * @var CreatePlan
     */
    private $createPlan;

    /**
     * @var CreateSubscription
     */
    private $createSubscription;

    /**
     * @var Adapter
     */
    private $adapter;

    /**
     * @var ConfigProvider
     */
    private $configProvider;

    /**
     * @var NewSubscriptionFactory
     */
    private $newSubscriptionFactory;

    /**
     * @var NewSubscriptionServiceInterface
     */
    private $newSubscriptionService;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        CreateProduct $createProduct,
        CreatePlan $createPlan,
        CreateSubscription $createSubscription,
        Adapter $adapter,
        ConfigProvider $configProvider = null, // TODO move to not optional
        NewSubscriptionFactory $newSubscriptionFactory = null, // TODO move to not optional
        NewSubscriptionServiceInterface $newSubscriptionService = null // TODO move to not optional
    ) {
        $this->productRepository = $productRepository;
        $this->createProduct = $createProduct;
        $this->createPlan = $createPlan;
        $this->createSubscription = $createSubscription;
        $this->adapter = $adapter;
        // OM for backward compatibility
        $this->configProvider = $configProvider ?? ObjectManager::getInstance()->get(ConfigProvider::class);
        $this->newSubscriptionFactory = $newSubscriptionFactory
            ?? ObjectManager::getInstance()->get(NewSubscriptionFactory::class);
        $this->newSubscriptionService = $newSubscriptionService
            ?? ObjectManager::getInstance()->get(NewSubscriptionServiceInterface::class);
    }

    /**
     * @param OrderInterface $order
     * @param AbstractItem $item
     * @param SubscriptionInterface $subscription
     */
    public function handle(OrderInterface $order, AbstractItem $item, SubscriptionInterface $subscription): void
    {
        $productId = $item->getProduct()->getId();

        try {
            /** @var PaypalProduct $product */
            $product = $this->productRepository->getByProductId($productId);
            // Ensure that product also exists on Paypal side
            $this->adapter->getProductDetails($product->getPaypalProductId());
        } catch (NoSuchEntityException $exception) {
            $product = $this->createProduct->execute($item, (int)$productId);
        } catch (PayPalApiException $exception) {
            $this->productRepository->delete($product);
            $product = $this->createProduct->execute($item, (int)$productId);
        }

        $planData = $this->createPlan->execute(
            $subscription,
            $item,
            (string)$product->getPaypalProductId(),
            $order
        );

        $subscriptionId = $this->createSubscription->execute(
            $subscription,
            $planData['id'],
            $order
        );
        $subscription->setSubscriptionId($subscriptionId);

        $this->addNewSubscriptionEntity($subscription);
    }

    private function addNewSubscriptionEntity($subscription)
    {
        if ($this->configProvider->isNotifySubscriptionCompletion()) {
            /** @var  NewSubscription $newSubscription */
            $newSubscription = $this->newSubscriptionFactory->create();
            $newSubscription->setSubscriptionId($subscription->getSubscriptionId());
            $this->newSubscriptionService->add($newSubscription);
        }
    }
}
