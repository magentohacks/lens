<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Trustpilot_Reviews',
    __DIR__
);
