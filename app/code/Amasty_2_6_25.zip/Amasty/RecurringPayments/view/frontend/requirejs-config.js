var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/price-box': {
                'Amasty_RecurringPayments/js/view/product/update-prices': true
            }
        }
    }
};
