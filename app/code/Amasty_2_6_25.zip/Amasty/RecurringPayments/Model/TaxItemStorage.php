<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model;

/**
 * Class TaxItemStorage
 */
class TaxItemStorage
{
    /**
     * storage for item
     *
     * @var \Magento\Quote\Model\Quote\Item|null
     */
    public static $item = null;
}
