<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model;

use Magento\Framework\Module\Manager;

class ModuleEnable
{
    public const SUBSCRIPTION_FUNCTIONALITY = 'Amasty_RecurringPaymentsSubscriptionFunctionality';

    /**
     * @var Manager
     */
    private $moduleManager;

    public function __construct(
        Manager $moduleManager
    ) {
        $this->moduleManager = $moduleManager;
    }

    public function isSubscriptionFunctionalityModuleEnabled(): bool
    {
        return $this->moduleManager->isEnabled(self::SUBSCRIPTION_FUNCTIONALITY);
    }
}
