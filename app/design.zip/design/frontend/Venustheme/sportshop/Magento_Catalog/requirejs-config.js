
var config = {
    map: {
        '*': {
            lensOptionData: 'Magento_Catalog/js/lensoption',
        }
    }
};