How to disclose potential security issues
============

As mPDF does not have a domain or a dedicated contact apart from its Github repository, to prevent 
disclosing maintainers' contacts publicly, please create an Issue about the security issue with means to contact you. 
We will reach out to you as soon as possible.
