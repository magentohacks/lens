define([
    'Amasty_RecurringPayments/js/form/element/abstract',
], function (Abstract) {
    'use strict';

    return Abstract.extend({
    });
});
