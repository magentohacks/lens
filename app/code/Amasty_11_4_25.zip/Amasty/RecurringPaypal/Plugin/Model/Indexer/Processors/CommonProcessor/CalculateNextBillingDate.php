<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Plugin\Model\Indexer\Processors\CommonProcessor;

use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPaymentsSubscriptionFunctionality\Model\Indexer\Processors\CommonProcessor;
use Amasty\RecurringPaypal\Exceptions\PayPalApiException;
use Amasty\RecurringPaypal\Model\Api\Adapter;
use Amasty\RecurringPaypal\Model\Subscription\Cache as SubscriptionCache;

class CalculateNextBillingDate
{
    /**
     * @var Adapter
     */
    private $adapter;

    /**
     * @var SubscriptionCache
     */
    private $subscriptionCache;

    public function __construct(
        Adapter $adapter,
        SubscriptionCache $subscriptionCache
    ) {
        $this->adapter = $adapter;
        $this->subscriptionCache = $subscriptionCache;
    }

    /**
     * @param CommonProcessor $subject
     * @param callable $proceed
     * @param array $subscriptionData
     * @return string
     */
    public function aroundGetNextBillingDate(
        CommonProcessor $subject, // @phpstan-ignore-line
        callable $proceed,
        array $subscriptionData
    ): string {
        if (in_array('paypal_express', $subject->getPaymentMethod())) {
            try {
                $cachedValue = $this->subscriptionCache
                    ->getSubscriptionData($subscriptionData[SubscriptionInterface::SUBSCRIPTION_ID]);
                if ($cachedValue === false) {
                    $details = $this->adapter
                        ->getSubscriptionDetails($subscriptionData[SubscriptionInterface::SUBSCRIPTION_ID]);
                    $this->subscriptionCache->saveSubscriptionData($details);
                } elseif (SubscriptionCache::BROKEN_RECORD === $cachedValue) {
                    return '';
                } else {
                    $details = $cachedValue;
                }
            } catch (PayPalApiException $e) {
                $this->subscriptionCache->markAsBroken($subscriptionData[SubscriptionInterface::SUBSCRIPTION_ID]);
                return ''; // Accidental paypal errors
            }

            return $details['billing_info']['next_billing_time'] ?? '';
        }

        return $proceed($subscriptionData);
    }
}
