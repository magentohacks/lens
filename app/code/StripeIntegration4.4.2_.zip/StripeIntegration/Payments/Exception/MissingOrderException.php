<?php

namespace StripeIntegration\Payments\Exception;

class MissingOrderException extends \StripeIntegration\Payments\Exception\WebhookException
{

}
