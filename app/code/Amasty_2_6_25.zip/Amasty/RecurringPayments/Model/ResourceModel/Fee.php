<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel;

use Amasty\RecurringPayments\Api\Data\FeeInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Fee extends AbstractDb
{
    public const TABLE_NAME = 'amasty_recurring_payments_fee_quote';

    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, FeeInterface::ENTITY_ID);
    }
}
