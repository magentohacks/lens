<?php

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Srinivas_CustomerApiSecurityPatch',
    __DIR__
);
