<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\Email;

use Amasty\RecurringPayments\Model\Config;
use Magento\Framework\App\Area;
use Magento\Framework\Mail\Template\TransportBuilder;
use Psr\Log\LoggerInterface;

class AdminNotification
{
    /**
     * @var TransportBuilder
     */
    private $transportBuilder;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var Config
     */
    private $config;

    public function __construct(
        Config $config,
        TransportBuilder $transportBuilder,
        LoggerInterface $logger
    ) {
        $this->config = $config;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $logger;
    }

    public function send(string $templateIdentifier, int $storeId, array $templateVars = []): void
    {
        $recipients = $this->config->getAdminEmailAddresses($storeId);
        $sender = $this->config->getAdminEmailSender($storeId);
        try {
            foreach ($recipients as $recipient) {
                $transportBuild = $this->transportBuilder->setTemplateIdentifier($templateIdentifier)
                    ->setTemplateOptions(['area' => Area::AREA_FRONTEND, 'store' => $storeId])
                    ->setTemplateVars($templateVars)
                    ->setFromByScope($sender, $storeId)
                    ->addTo($recipient);
                $transportBuild->getTransport()->sendMessage();
            }
        } catch (\Exception $e) {
            $this->logger->critical($e);
        }
    }
}
