<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Controller\Adminhtml\Product;

use Amasty\RecurringPayments\Api\Data\ProductRecurringAttributesInterface;
use Magento\Backend\App\Action\Context;
use Magento\Catalog\Model\Product\Action;
use Magento\Catalog\Controller\Adminhtml\Product;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Module\Manager;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

class ChangeRecurring extends Product
{
    public const CREDIT_PRODUCT_TYPE_CODE = 'amstore_credit_product';

    /**
     * MassActions filter
     *
     * @var Filter
     */
    private $filter;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var Action
     */
    private $productAction;

    /**
     * @var Manager
     */
    private $moduleManager;

    public function __construct(
        Context $context,
        Product\Builder $productBuilder,
        Filter $filter,
        CollectionFactory $collectionFactory,
        Action $productAction,
        Manager $moduleManager = null // TODO move to not optional
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->productAction = $productAction;
        $this->moduleManager = $moduleManager ?? ObjectManager::getInstance()->get(Manager::class);
        parent::__construct($context, $productBuilder);
    }

    /**
     * Enable product(s) for recurring payments action
     *
     * @inheritDoc
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $hasStoreCreditProducts = $this->checkStoreCreditProduct($collection);
        $productIds = $collection->getAllIds();
        $requestStoreId = $storeId = $this->getRequest()->getParam('store', null);
        $filterRequest = $this->getRequest()->getParam('filters', null);
        $statusOfRecurring = constant($this->getRequest()->getParam('status_of_recurring', null));

        if (null !== $storeId && null !== $filterRequest) {
            $storeId = (int)$filterRequest['store_id'] ?? 0;
        }

        try {
            $this->productAction->updateAttributes(
                $productIds,
                [
                    ProductRecurringAttributesInterface::RECURRING_ENABLE => $statusOfRecurring
                ],
                (int)$storeId
            );
            $this->messageManager->addSuccessMessage(
                __('A total of %1 record(s) have been updated.', count($productIds))
            );
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            if (!($hasStoreCreditProducts && empty($productIds))) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                __('Something went wrong while updating the product(s) status.')
            );
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        return $resultRedirect->setPath('catalog/*/', ['store' => $requestStoreId]);
    }

    private function checkStoreCreditProduct(Collection $collection): bool
    {
        if (!$this->moduleManager->isEnabled("Amasty_StoreCredit")) {
            return false;
        }

        $hasStoreCredit = false;

        foreach ($collection->getItems() as $item) {
            if ($item->getData('type_id') === self::CREDIT_PRODUCT_TYPE_CODE) {
                $hasStoreCredit = true;
                break;
            }
        }

        if ($hasStoreCredit) {
            $collection->addFieldToFilter('type_id', ['neq'=> self::CREDIT_PRODUCT_TYPE_CODE]);
            $this->messageManager->addWarningMessage(
                __("Store Credit Product cannot be selected as a subscription product")
            );

            return true;
        }

        return false;
    }
}
