<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Api\Subscription;

/**
 * Interface ProcessorInterface
 */
interface GridInterface
{
    /**
     * You must return array of subscriptions
     * array of object \Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface
     *
     * @param int $customerId
     *
     * @return \Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface[]
     */
    public function process(int $customerId);
}
