<?php

namespace StripeIntegration\Payments\Exception;

class SCANeededException extends \Exception
{

}
