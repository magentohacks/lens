<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Api\Data;

interface ProductRecurringAttributesInterface
{
    public const RECURRING_ENABLE = 'am_recurring_enable';
    public const SUBSCRIPTION_ONLY = 'am_subscription_only';
    public const START_DATE = 'am_rec_start_date';
    public const END_DATE = 'am_rec_end_date';
    public const COUNT_CYCLES = 'am_rec_count_cycles';
    public const TIMEZONE = 'am_rec_timezone';
    public const PLANS = 'am_rec_plans';
    public const SUBSCRIPTION_PLAN_ID = 'am_rec_subscription_plan_id';
}
