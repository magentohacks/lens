<?php

namespace StripeIntegration\Payments\Exception;

class PaymentMethodInUse extends GenericException
{

}
