<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Plugin\Amasty\RecurringPayments\Restrict;

use Amasty\RecurringPayments\Model\Product\Source\AvailableSubscription;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\RequestInterface;

class StoreCreditProductPlugin
{
    public const CREDIT_PRODUCT_TYPE_CODE = 'amstore_credit_product';

    /**
     * @var RequestInterface
     */
    private RequestInterface $request;

    /**
     * @var ProductRepositoryInterface
     */
    private ProductRepositoryInterface $productRepository;

    public function __construct(
        RequestInterface $request,
        ProductRepositoryInterface $productRepository
    ) {
        $this->request = $request;
        $this->productRepository = $productRepository;
    }

    public function afterToArray(AvailableSubscription $subject, array $result): array
    {
        if ($this->request->getParam('type') === self::CREDIT_PRODUCT_TYPE_CODE
            || $this->getProductType($this->request->getParam('id')) === self::CREDIT_PRODUCT_TYPE_CODE) {
            return [
                AvailableSubscription::NO => __('No')
            ];
        }

        return $result;
    }

    private function getProductType($id): string
    {
        if (!$id) {
            return '';
        }

        try {
            return $this->productRepository->getById($id)->getTypeId();
        } catch (\Exception $e) {
            return '';
        }
    }
}
