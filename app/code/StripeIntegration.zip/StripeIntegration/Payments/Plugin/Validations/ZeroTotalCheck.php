<?php
namespace StripeIntegration\Payments\Plugin\Validations;

use Magento\Payment\Model\MethodInterface;
use Magento\Quote\Model\Quote;
use Magento\Payment\Model\Checks\ZeroTotal;

class ZeroTotalCheck
{
    private $quoteHelper;

    public function __construct(
        \StripeIntegration\Payments\Helper\Quote $quoteHelper
    )
    {
        $this->quoteHelper = $quoteHelper;
    }

    /**
     * After plugin for isApplicable method
     *
     * @param ZeroTotal $subject
     * @param bool $result
     * @param MethodInterface $paymentMethod
     * @param Quote $quote
     * @return bool
     */
    public function afterIsApplicable(ZeroTotal $subject, $result, MethodInterface $paymentMethod, Quote $quote)
    {
        $hasNonBillableSubscriptionItems = !empty($this->quoteHelper->getNonBillableSubscriptionItems($quote->getAllItems()));

        if ($hasNonBillableSubscriptionItems)
        {
            return true;
        }

        return $result;
    }
}
