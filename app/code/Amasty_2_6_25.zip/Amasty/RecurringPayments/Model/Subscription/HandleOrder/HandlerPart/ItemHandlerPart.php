<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\Subscription\HandleOrder\HandlerPart;

use Amasty\RecurringPayments\Api\Data\TransactionInterface;
use Amasty\RecurringPayments\Api\Generators\RecurringTransactionGeneratorInterface;
use Amasty\RecurringPayments\Api\TransactionRepositoryInterface;
use Amasty\RecurringPayments\Model\Config\Source\Status;
use Amasty\RecurringPayments\Model\Subscription\HandleOrder\HandleOrderContext;
use Amasty\RecurringPayments\Model\Subscription\HandleOrder\HandlerPartInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

class ItemHandlerPart implements HandlerPartInterface
{
    public const DEFAULT_REFUND_STATUS = '-';

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    /**
     * @var string[]
     */
    private $refundStatuses;

    /**
     * @var RecurringTransactionGeneratorInterface
     */
    private $recurringTransactionGenerator;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        TransactionRepositoryInterface $transactionRepository,
        RecurringTransactionGeneratorInterface $recurringTransactionGenerator,
        OrderRepositoryInterface $orderRepository,
        SerializerInterface $serializer,
        array $refundStatuses = []
    ) {
        $this->productRepository = $productRepository;
        $this->transactionRepository = $transactionRepository;
        $this->refundStatuses = $refundStatuses;
        $this->recurringTransactionGenerator = $recurringTransactionGenerator;
        $this->orderRepository = $orderRepository;
        $this->serializer = $serializer;
    }

    public function handlePartial(HandleOrderContext $context): bool
    {
        $subscription = $context->getSubscription();

        try {
            $product = $this->productRepository->getById($subscription->getProductId());

            if ($product->getTypeId() == Configurable::TYPE_CODE) {
                $attributes = $this->serializer->unserialize($subscription->getProductOptions());
                if (is_array($attributes) && isset($attributes['super_attribute'])) {
                    $attributes = $attributes['super_attribute'];
                } else {
                    $attributes = [];
                }
                $product =  $product->getTypeInstance()->getProductByAttributes(
                    $attributes,
                    $product
                );
            }
        } catch (\Exception $e) {
            $this->saveTransaction($context);
            $context->setNeedToRefundMoney(true);

            return false;
        }

        if (!$product || !$product->isSalable()) {
            $this->saveTransaction($context);
            $context->setNeedToRefundMoney(true);

            return false;
        }

        return true;
    }

    public function validate(HandleOrderContext $context): void
    {
        if (!$context->getSubscription()) {
            throw new \InvalidArgumentException('No subscription in context');
        }
    }

    private function saveTransaction(HandleOrderContext $context): void
    {
        if ($recurringTransaction = $context->getRecurringTransaction()) {
            $this->updateTransactionStatus($recurringTransaction);

            return;
        }

        $subscription = $context->getSubscription();
        $order = $this->orderRepository->get($subscription->getOrderId());

        $recurringTransaction = $this->recurringTransactionGenerator->generate(
            (float)$order->getBaseGrandTotal(),
            $order->getIncrementId(),
            $order->getOrderCurrencyCode(),
            uniqid('trans_', true),
            Status::FAILED,
            $subscription->getSubscriptionId()
        );
        $context->setRecurringTransaction($recurringTransaction);

        $this->transactionRepository->save($recurringTransaction);
    }

    private function updateTransactionStatus(TransactionInterface $recurringTransaction): void
    {
        $recurringTransaction->setstatus(Status::FAILED);
        $this->transactionRepository->save($recurringTransaction);
    }

    public function getRefundStatus(string $paymentMethod): string
    {
        if (isset($this->refundStatuses[$paymentMethod])) {
            return $this->refundStatuses[$paymentMethod];
        }

        return self::DEFAULT_REFUND_STATUS;
    }
}
