<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model\Api\Transport;

use Amasty\RecurringPaypal\Model\ConfigProvider;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Encryption\Encryptor;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\Client\CurlFactory;

class OAuthTokenCredential
{
    public const TOKEN_TABLE = 'amasty_recurring_payments_paypal_oauth';

    /**
     * @var ConfigProvider
     */
    private $config;

    /**
     * @var ResourceConnection
     */
    private $resourceConnection;

    /**
     * @var CurlFactory
     */
    private $curlFactory;

    /**
     * @var Encryptor
     */
    private $encryptor;

    /**
     * Generated Access Token
     *
     * @var string $accessToken
     */
    private $accessToken;

    /**
     * Seconds for with access token is valid
     *
     * @var $tokenExpiresIn
     */
    private $tokenExpiresIn;

    /**
     * Last time (in milliseconds) when access token was generated
     *
     * @var $tokenCreateTime
     */
    private $tokenCreateTime;

    public function __construct(
        ConfigProvider $config,
        ResourceConnection $resourceConnection,
        CurlFactory $curlFactory,
        Encryptor $encryptor
    ) {
        $this->config = $config;
        $this->resourceConnection = $resourceConnection;
        $this->curlFactory = $curlFactory;
        $this->encryptor = $encryptor;
    }

    public function getAccessToken(): string
    {
        // Check if we already have accessToken in Cache
        if ($this->accessToken && (time() - $this->tokenCreateTime) < $this->tokenExpiresIn) {
            return $this->accessToken;
        }

        if ($tokenData = $this->getTokenData()) {
            $this->accessToken = $this->encryptor->decrypt($tokenData['access_token']['value']);
            $this->tokenCreateTime = $tokenData['token_create_time']['value'];
            $this->tokenExpiresIn = $tokenData['token_expires_in']['value'];
        }

        if ($this->accessToken && (time() - $this->tokenCreateTime) > $this->tokenExpiresIn) {
            $this->accessToken = null;
        }

        if ($this->accessToken === null) {
            // Get a new one by making calls to API
            $this->generateAccessToken();
            $this->setTokenData(
                $this->encryptor->encrypt($this->accessToken),
                $this->tokenExpiresIn,
                $this->tokenCreateTime
            );
        }

        return $this->accessToken;
    }

    private function generateAccessToken(): string
    {
        $credentials = implode(':', $this->config->getPaypalCredentials());
        $response = $this->accessTokenPost($credentials);

        if ($response === null || !isset($response["access_token"]) || !isset($response["expires_in"])) {
            $this->accessToken = null;
            $this->tokenExpiresIn = null;
            throw new LocalizedException(__("Could not generate new Access token. Invalid response from server"));
        }

        $this->accessToken = $response["access_token"];
        $this->tokenExpiresIn = $response["expires_in"];
        $this->tokenCreateTime = $this->accessToken ? time() : null;

        return $this->accessToken;
    }

    private function getTokenData(): array
    {
        $connection = $this->resourceConnection->getConnection();
        $table = $this->resourceConnection->getTableName(self::TOKEN_TABLE);
        $select = $connection->select()
            ->from($table, ['name', 'value'])
            ->where('`name` IN(?)', ['access_token', 'token_expires_in', 'token_create_time']);

        return $connection->fetchAssoc($select);
    }

    private function setTokenData(string $accessToken, int $tokenExpiresIn, int $tokenCreateTime): void
    {
        $connection = $this->resourceConnection->getConnection();
        $table = $this->resourceConnection->getTableName(self::TOKEN_TABLE);
        $data = [
            ['name' => 'access_token', 'value' => $accessToken],
            ['name' => 'token_expires_in', 'value' => $tokenExpiresIn],
            ['name' => 'token_create_time', 'value' => $tokenCreateTime],
        ];
        $connection->insertMultiple($table, $data);
    }

    private function accessTokenPost($credentials): ?array
    {
        $curl = $this->curlFactory->create();
        $curl->addHeader('Content-Type', 'application/x-www-form-urlencoded');
        $curl->addHeader('Authorization', 'Basic ' . base64_encode($credentials));
        $uri = $this->config->getFullApiUrl('/v1/oauth2/token');
        $curl->post($uri, ['grant_type' => 'client_credentials']);

        return json_decode($curl->getBody(), true);
    }

    public function refreshTokenData(): void
    {
        $connection = $this->resourceConnection->getConnection();
        $table = $this->resourceConnection->getTableName(self::TOKEN_TABLE);
        $connection->truncateTable($table);
        $this->accessToken = null;
    }
}
