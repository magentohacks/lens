<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Cron;

use Amasty\RecurringPayments\Model\Subscription\Scheduler\Generator;

class GenerateSchedule
{
    /**
     * @var Generator
     */
    private $generator;

    public function __construct(Generator $generator)
    {
        $this->generator = $generator;
    }

    /**
     * Generate schedule for subscriptions
     *
     * @return void
     */
    public function execute()
    {
        $this->generator->generate();
    }
}
