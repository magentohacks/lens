 require([
      'https://consent.cookiebot.com/uc.js?870f4eef-fc29-43a3-b216-980886aa98f1',
      'domReady!'
    ], function () {
      'use strict';
    });