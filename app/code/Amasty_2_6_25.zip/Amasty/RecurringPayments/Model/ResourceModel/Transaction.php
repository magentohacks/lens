<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel;

use Amasty\RecurringPayments\Api\Data\TransactionInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Transaction extends AbstractDb
{
    public const TABLE_NAME = 'amasty_recurring_payments_transaction_log';

    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, TransactionInterface::ENTITY_ID);
    }
}
