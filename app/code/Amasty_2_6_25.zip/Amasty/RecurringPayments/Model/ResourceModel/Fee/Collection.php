<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel\Fee;

use Amasty\RecurringPayments\Model\Fee;
use Amasty\RecurringPayments\Model\ResourceModel\Fee as FeeResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 */
class Collection extends AbstractCollection
{
    public function _construct()
    {
        $this->_init(Fee::class, FeeResource::class);
    }
}
