<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel;

use Amasty\RecurringPayments\Api\Data\DiscountInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Discount extends AbstractDb
{
    public const TABLE_NAME = 'amasty_recurring_payments_discount';

    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, DiscountInterface::ENTITY_ID);
    }
}
