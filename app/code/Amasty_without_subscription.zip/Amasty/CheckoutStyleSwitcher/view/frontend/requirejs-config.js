/* jshint browser:true jquery:true */
var amasty_mixin_enabled = !window.amasty_checkout_disabled,
    config;

config = {
    config: {
        mixins: {
            'Magento_Paypal/js/view/payment/method-renderer/in-context/checkout-express': {
                'Amasty_CheckoutStyleSwitcher/js/view/payment/checkout-express-mixin': amasty_mixin_enabled
            }
        }
    }
};
