<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\ResourceModel\SubscriptionPlan;

use Amasty\RecurringPayments\Model\ResourceModel\SubscriptionPlan as SubscriptionPlanResource;
use Amasty\RecurringPayments\Model\SubscriptionPlan;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Init data model and resource model
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init(SubscriptionPlan::class, SubscriptionPlanResource::class);
    }
}
