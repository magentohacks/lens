<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model\WebHook\Handler\Payment\Sale;

use Amasty\RecurringPayments\Api\Data\TransactionInterface;
use Amasty\RecurringPayments\Api\Generators\RecurringTransactionGeneratorInterface;
use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Api\TransactionRepositoryInterface;
use Amasty\RecurringPayments\Model\Date;
use Amasty\RecurringPayments\Model\Subscription\HandleOrder\CompositeHandler;
use Amasty\RecurringPayments\Model\Subscription\HandleOrder\CompositeHandlerFactory;
use Amasty\RecurringPayments\Model\Subscription\HandleOrder\HandleOrderContext;
use Amasty\RecurringPayments\Model\Subscription\HandleOrder\HandleOrderContextFactory;
use Amasty\RecurringPaypal\Api\WebHook\HandlerInterface;
use Amasty\RecurringPaypal\Model\Api\Adapter;
use Amasty\RecurringPaypal\Model\Processor\RenewSubscription;
use Amasty\RecurringPaypal\Model\Subscription\Cache as SubscriptionCache;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\OrderRepositoryInterface;
use Psr\Log\LoggerInterface;

class Completed implements HandlerInterface
{
    /**
     * @var RepositoryInterface
     */
    private $subscriptionRepository;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var Date
     */
    private $date;

    /**
     * @var RenewSubscription
     */
    private $renewSubscription;

    /**
     * @var SubscriptionCache
     */
    private $subscriptionCache;

    /**
     * @var CompositeHandlerFactory
     */
    private $compositeHandlerFactory;

    /**
     * @var HandleOrderContextFactory
     */
    private $handleOrderContextFactory;

    /**
     * @var RecurringTransactionGeneratorInterface
     */
    private $recurringTransactionGenerator;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var Adapter
     */
    private $adapter;

    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    public function __construct(
        RepositoryInterface $subscriptionRepository,
        OrderRepositoryInterface $orderRepository,
        Date $date,
        RenewSubscription $renewSubscription,
        SubscriptionCache $subscriptionCache,
        CompositeHandlerFactory $compositeHandlerFactory,
        HandleOrderContextFactory $handleOrderContextFactory,
        RecurringTransactionGeneratorInterface $recurringTransactionGenerator,
        LoggerInterface $logger = null, //todo move to not optional
        Adapter $adapter = null, //todo move to not optional
        TransactionRepositoryInterface $transactionRepository = null //todo move to not optional
    ) {
        $this->subscriptionRepository = $subscriptionRepository;
        $this->orderRepository = $orderRepository;
        $this->date = $date;
        $this->renewSubscription = $renewSubscription;
        $this->subscriptionCache = $subscriptionCache;
        $this->compositeHandlerFactory = $compositeHandlerFactory;
        $this->handleOrderContextFactory = $handleOrderContextFactory;
        $this->recurringTransactionGenerator = $recurringTransactionGenerator;
        // OM for backward compatibility
        $this->logger = $logger ?? ObjectManager::getInstance()->get(LoggerInterface::class);
        $this->adapter = $adapter ?? ObjectManager::getInstance()->get(Adapter::class);
        $this->transactionRepository = $transactionRepository
            ?? ObjectManager::getInstance()->get(TransactionRepositoryInterface::class);
    }

    /**
     * @param array $payload
     */
    public function process(array $payload)
    {
        $payment = $payload['resource'];
        $subscriptionId = $payment['billing_agreement_id'];
        $transactionId = $payment['id'];

        $recurringTransaction = $this->recurringTransactionGenerator->generate(
            (float)$payment['amount']['total'],
            '',
            $payment['amount']['currency'],
            $payment['id'],
            TransactionInterface::STATUS_SUCCESS,
            $subscriptionId,
            $this->date->convertFromUnix(strtotime($payment['create_time']))
        );

        try {
            $subscription = $this->subscriptionRepository->getBySubscriptionId($subscriptionId);
        } catch (NoSuchEntityException $e) {
            $recurringTransaction->setStatus(TransactionInterface::STATUS_FAIL);
            $this->transactionRepository->save($recurringTransaction);
            $this->createRefund($transactionId);
            try {
                $this->adapter->cancelSubscription($subscriptionId, (string)__('Subscription is no longer available'));
            } catch (\Exception $e) {
                return;
            }

            return;
        }

        /** @var HandleOrderContext $handleOrderContext */
        $handleOrderContext = $this->handleOrderContextFactory->create();

        $handleOrderContext->setSubscription($subscription);
        $handleOrderContext->setTransactionId($transactionId);
        $order = $this->orderRepository->get($subscription->getOrderId());

        $recurringTransaction->setOrderId($order->getIncrementId());

        $handleOrderContext->setRecurringTransaction($recurringTransaction);

        /** @var CompositeHandler $compositeHandler */
        $compositeHandler = $this->compositeHandlerFactory->create();
        $compositeHandler->handle($handleOrderContext);

        if ($handleOrderContext->isNeedToRefundMoney()) {
            $this->createRefund($transactionId);
        }

        if ($subscription->getRemainingDiscountCycles() > 0) {
            $subscription->setRemainingDiscountCycles(
                $subscription->getRemainingDiscountCycles() - 1
            );
            $this->subscriptionRepository->save($subscription);

            if ($subscription->getRemainingDiscountCycles() === 0) {
                $this->renewSubscription->execute($subscription);
            }
        }

        $this->subscriptionCache->clearSubscriptionData((string)$subscription->getSubscriptionId());
    }

    private function createRefund(string $transactionId): void
    {
        try {
            $this->adapter->refundPayment($transactionId, ['reason' => 'The product is unavailable.']);
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
        }
    }
}
