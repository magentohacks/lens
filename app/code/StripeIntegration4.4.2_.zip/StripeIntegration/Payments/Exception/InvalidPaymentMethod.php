<?php

namespace StripeIntegration\Payments\Exception;

class InvalidPaymentMethod extends GenericException
{

}
