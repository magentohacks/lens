<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Model\Config\Source;

use Amasty\RecurringPayments\Model\AbstractArray;

class TrialEnableDisable extends AbstractArray
{
    public const DISABLE = 0;
    public const ENABLE = 1;

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            self::DISABLE => __('Disable'),
            self::ENABLE => __('Enable'),
        ];
    }
}
