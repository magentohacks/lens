<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Api\Config;

interface ValidatorInterface
{
    /**
     * @return \Generator Error messages
     */
    public function enumerateConfigurationIssues(): \Generator;
}
