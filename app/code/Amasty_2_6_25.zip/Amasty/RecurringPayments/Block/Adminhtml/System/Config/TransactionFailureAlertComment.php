<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Block\Adminhtml\System\Config;

use Magento\Config\Model\Config\CommentInterface;
use Magento\Framework\View\Element\AbstractBlock;

class TransactionFailureAlertComment extends AbstractBlock implements CommentInterface
{
    public const PAYPAL_WEBHOOK_URL = 'https://developer.paypal.com/developer/dashboard/webhooks/sandbox/';

    /**
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function getCommentText($elementValue): string
    {
        $supportedPaymentMethods = explode(
            ',',
            (string)$this->_scopeConfig->getValue('amasty_recurring_payments/general/supported_payments')
        );

        if (in_array('paypal_express', $supportedPaymentMethods)) {
            return (string)__('To ensure the correct operation of notifications regarding issues with PayPal '
                . 'transactions, please make sure the "Billing subscription payment failed" event is enabled in your '
                . '<a href="%1">PayPal Developer Dashboard.</a>', self::PAYPAL_WEBHOOK_URL);
        }

        return '';
    }
}
