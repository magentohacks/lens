<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model;

use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Model\Subscription\Email\EmailNotifier;
use Amasty\RecurringPaypal\Exceptions\PayPalApiException;
use Amasty\RecurringPaypal\Model\Api\Adapter;
use Amasty\RecurringPaypal\Model\Subscription\StatusMapper;

class SendCompletionEmail
{
    public const MINUTES = 20;

    /**
     * @var Adapter
     */
    private $adapter;

    /**
     * @var RepositoryInterface
     */
    private $subscriptionRepository;

    /**
     * @var EmailNotifier
     */
    private $emailNotifier;

    /**
     * @var ConfigProvider
     */
    private $configProvider;

    public function __construct(
        ConfigProvider $configProvider,
        Adapter $adapter,
        EmailNotifier $emailNotifier,
        RepositoryInterface $subscriptionRepository
    ) {
        $this->configProvider = $configProvider;
        $this->adapter = $adapter;
        $this->emailNotifier = $emailNotifier;
        $this->subscriptionRepository = $subscriptionRepository;
    }

    public function send(string $subscriptionId): void
    {
        try {
            $subscriptionDetails = $this->adapter->getSubscriptionDetails($subscriptionId);
        } catch (PayPalApiException $e) {
            return;
        }
        if (isset($subscriptionDetails['status'])
            && $subscriptionDetails['status'] === StatusMapper::APPROVAL_PENDING
        ) {
            $subscription = $this->subscriptionRepository->getBySubscriptionId($subscriptionId);
            $template = $this->configProvider->getEmailTemplateSubscriptionCompletion();
            $templateVars = [
                'confirmation_link' =>$this->getConfirmationLink($subscriptionDetails)
            ];

            $this->emailNotifier->sendEmail($subscription, $template, $templateVars);
        }
    }

    private function getConfirmationLink(array $subscriptionDetails): string
    {
        foreach ($subscriptionDetails['links'] as $link) {
            if ($link['rel'] == 'approve') {
                return $link['href'];
            }
        }

        return '';
    }
}
