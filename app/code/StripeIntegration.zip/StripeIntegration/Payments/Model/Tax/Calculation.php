<?php

namespace StripeIntegration\Payments\Model\Tax;

class Calculation
{
    public $method = null;
}
