<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2 (System)
 */

namespace Amasty\RecurringPayments\Api\Subscription;

interface NotificationInterface
{
    public const INTERVAL = 'interval';
    public const INITIAL_FEE = 'initial_fee';
    public const REGULAR_PAYMENT = 'regular_payment';
    public const DISCOUNT_AMOUNT = 'discount_amount';
    public const PAYMENT_WITH_DISCOUNT = 'payment_with_discount';
    public const DISCOUNT_CYCLE = 'discount_cycle';
    public const TRIAL_STATUS = 'trial_status';
    public const TRIAL_DAYS = 'trial_days';
    public const START_DATE = 'start_date';
}
