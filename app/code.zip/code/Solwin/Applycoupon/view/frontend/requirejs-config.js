/**
 * Solwin Infotech
 * Solwin Discount Coupon Code Link Extension
 *
 * @category   Solwin
 * @package    Solwin_Applycoupon
 * @copyright  Copyright © 2006-2018 Solwin (https://www.solwininfotech.com)
 * @license    https://www.solwininfotech.com/magento-extension-license/ 
 */
var config = {
    map: {
        '*': {
            cpfancybox: 'Solwin_Applycoupon/js/fancybox/jquery.fancybox.pack'
        }
    }
};