<?php

namespace StripeIntegration\Payments\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface SubscriptionOptionsInterface extends ExtensibleDataInterface
{

}
