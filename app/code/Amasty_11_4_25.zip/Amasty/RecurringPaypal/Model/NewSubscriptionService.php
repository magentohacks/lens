<?php

declare(strict_types=1);

/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Subscriptions & Recurring Payments for Magento 2: Paypal (System)
 */

namespace Amasty\RecurringPaypal\Model;

use Amasty\RecurringPaypal\Api\Data\NewSubscriptionInterface;
use Amasty\RecurringPaypal\Api\NewSubscriptionServiceInterface;
use Amasty\RecurringPaypal\Model\ResourceModel\NewSubscription as NewSubscriptionResource;
use Amasty\RecurringPaypal\Model\ResourceModel\NewSubscription\CollectionFactory;
use Magento\Framework\Exception\CouldNotSaveException;

class NewSubscriptionService implements NewSubscriptionServiceInterface
{
    /**
     * @var NewSubscriptionResource
     */
    private $newSubscriptionResource;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    public function __construct(
        NewSubscriptionResource $newSubscriptionResource,
        CollectionFactory $collectionFactory
    ) {
        $this->newSubscriptionResource = $newSubscriptionResource;
        $this->collectionFactory = $collectionFactory;
    }

    public function add(NewSubscriptionInterface $newSubscription): void
    {
        try {
            $this->newSubscriptionResource->save($newSubscription);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(
                __(
                    'Could not save the New Subscription: %1',
                    $exception->getMessage()
                )
            );
        }
    }

    /**
     * @param int|null $minutes
     * @return NewSubscriptionInterface[]
     */
    public function shuffleNewSubscriptions(?int $minutes): array
    {
        $collection = $this->collectionFactory->create();
        if ($minutes) {
            $collection->getSelect()
                ->where(NewSubscriptionInterface::CREATED_AT . ' < NOW() - INTERVAL ? MINUTE', $minutes);
        }

        $items = $collection->getItems();
        $ids = $collection->getColumnValues(NewSubscriptionInterface::ID);

        if (!empty($ids)) {
            $this->newSubscriptionResource->deleteByIds($ids);
        }

        return $items;
    }
}
